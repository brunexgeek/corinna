package corinna.service.bindlet.http;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.bindlet.IBindlet;
import javax.bindlet.IBindletContext;

import corinna.core.Context;
import corinna.core.IBindletRegistration;
import corinna.core.IService;
import corinna.core.http.IHttpContext;
import corinna.network.RequestEvent;

// TODO: move para 'corinna.core.http'
public class HttpContext extends Context<IHttpBindletRequest, IHttpBindletResponse> implements
	IHttpContext
{

	private static final String BINDLET_URL_MAPPING = "urlMapping";
	
	private static final String CONTEXT_URL_MAPPING = "urlMapping";

	public HttpContext( String name, IService service )
	{
		super(name, service);
	}

	@Override
	public IBindlet<IHttpBindletRequest, IHttpBindletResponse> createHttpBindlet(
		String bindletMapping )
	{
		return null;
	}

	@Override
	protected IBindletContext createBindletContext()
	{
		return new HttpBindletContext(this);
	}

	@Override
	public IBindletRegistration getBindletRegistration( IHttpBindletRequest request )
	{
		IBindletRegistration[] regs = getBindletRegistrations();

		for (IBindletRegistration current : regs)
		{
			String value = current.getBindletParameter(BINDLET_URL_MAPPING);
			if (value == null) continue;

			Pattern pattern = Pattern.compile(value);
			Matcher match = pattern.matcher( request.getResourcePath() );

			if (match.find() && match.start() == 0)
			{
				if (request instanceof HttpBindletRequest)
					((HttpBindletRequest)request).setBindletPath(match.group());
				return current;
			}
		}
		
		return null;
	}

	@Override
	protected boolean acceptRequest( IHttpBindletRequest request )
	{
		String uri = request.getResourcePath();
		String value = getParameter(CONTEXT_URL_MAPPING);
		if (value == null) return false;
		
		/*if (!value.isEmpty() && value.charAt( value.length()-1 ) != '/')
			value += "/";
		if (!uri.isEmpty() && uri.charAt( uri.length()-1 ) != '/')
			uri += "/";*/

		Pattern pattern = Pattern.compile(value);
		Matcher match = pattern.matcher(uri);
		
		if (match.find() && match.start() == 0)
		{
			if (request instanceof HttpBindletRequest)
				((HttpBindletRequest)request).setContextPath(match.group());
			return true;
		}
		
		return false;
	}

}
