package corinna.service.bindlet.http;

import java.io.BufferedReader;
import java.io.IOException;

import javax.bindlet.BindletInputStream;

import org.jboss.netty.handler.codec.http.HttpHeaders;
import org.jboss.netty.handler.codec.http.HttpRequest;

//TODO: mover para 'javax.bindlet.http'
public class WebBindletRequest implements IWebBindletRequest
{


	private HttpRequest request;
	
	private String serverName = null;
	
	private int serverPort = 0;
	
	private String contextPath = "";
	
	private String bindletPath = "";

	private String queryString = "";

	private String resourcePath = null;
	
	public WebBindletRequest( HttpRequest request )
	{
		if (request == null)
			throw new NullPointerException("The internal request can not be null");
		
		this.request = request;
		
		parseHost( request.getHeader(HttpHeaders.Names.HOST) );
		parseUri(request.getUri());
	}
	
	protected void parseHost( String host )
	{
		if (host == null || host.isEmpty()) return;
		
		serverPort = 80;
		serverName = "";
		
		int pos = host.indexOf(":");
		if (pos < 0 || pos + 1 == host.length())
			serverName = host;
		else
		{
			serverName = host.substring(0, pos);
			String port = host.substring(pos+1, host.length());
			serverPort = Integer.parseInt(port);
		}
	}
	
	protected void parseUri( String uri )
	{
		resourcePath = uri;
		
		// extract the query string
		int pos = uri.indexOf("?");
		if (pos >= 0 && pos < (uri.length()-1))
			queryString = uri.substring(pos+1);
		resourcePath = uri.substring(0, pos);
	}
	
	@Override
	public long getDateHeader( String name )
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getHeader( String name )
	{
		return request.getHeader(name);
	}

	@Override
	public String[] getHeaders( String name )
	{
		String value = getHeader(name);
		if (value != null)
			return value.split(";");
		else
			return null;
	}

	@Override
	public String[] getHeaderNames()
	{
		return request.getHeaderNames().toArray( new String[0] );
	}

	@Override
	public String getMethod()
	{
		return request.getMethod().getName();
	}

	@Override
	public String getPathInfo()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getContextPath()
	{
		return contextPath;
	}

	@Override
	public String getQueryString()
	{
		return queryString;
	}

	@Override
	public StringBuffer getRequestURL()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBindletPath()
	{
		return bindletPath;
	}

	@Override
	public BindletInputStream getInputStream() throws IOException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getProtocol()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getScheme()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getServerName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getServerPort()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BufferedReader getReader() throws IOException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRemoteAddr()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRemoteHost()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isSecure()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getRemotePort()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getLocalName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocalAddr()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getLocalPort()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUri()
	{
		return request.getUri();
	}
	
	@Override
	public String getResourcePath()
	{
		return resourcePath ;
	}
	
	/**
	 * Defines the context path for this request. This method extract the real context path from
	 * URI, which will returned by {@link #getContextPath()} and the rest of URI will be returned by
	 * {@link #getBindletPath()}.
	 * 
	 * @param path
	 */
	public void setContextPath( String path )
	{
		if (path == null)
			throw new NullPointerException("The bindlet context path can not be null");
		
		String url = getResourcePath();
		if (!url.startsWith(path))
			throw new IllegalArgumentException("The bindlet context path must be the prefix of request URI");
		
		contextPath = path;
		bindletPath = "";
		queryString = "";
		resourcePath = url.substring( path.length() );
		//if (!resourcePath.startsWith("/")) resourcePath = "/" + resourcePath;
	}
	
	public void setBindletPath( String path )
	{
		if (path == null)
			throw new NullPointerException("The bindlet path can not be null");
		if (resourcePath == null)
			throw new NullPointerException("The bindlet context path must be setted");
		
		bindletPath = path;
		if (!resourcePath.startsWith(path))
			throw new IllegalArgumentException("The bindlet context path must be the prefix of request resource path");
		if (path.length() < resourcePath.length())
			resourcePath = resourcePath.substring( path.length() );
		else
			resourcePath = "";
	}
	
}
