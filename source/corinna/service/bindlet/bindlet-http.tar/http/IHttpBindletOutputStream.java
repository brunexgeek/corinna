//package corinna.service.bindlet.http;
//
//
//import java.io.IOException;
//
//
//public interface IHttpBindletOutputStream
//{
//
//}
