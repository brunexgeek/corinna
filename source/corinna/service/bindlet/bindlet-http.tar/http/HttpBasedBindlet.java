package corinna.service.bindlet.http;



public class HttpBasedBindlet
{
	
}
